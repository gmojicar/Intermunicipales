package co.edu.unal.poo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity  //implements MapasFragment.OnFragmentInteractionListener
 {

    Button btnmapa,btnubicacion,btndestino;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btndestino = (Button) findViewById(R.id.btn_destino);
        btnmapa = (Button) findViewById(R.id.btn_mapa);
        btnubicacion = (Button) findViewById(R.id.btn_ubicacion);

        btndestino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MapsActivity1.class);
                startActivity(intent);
            }
        });

        btnmapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MapsActivityMapa.class);
                startActivity(intent);
            }
        });

        btnubicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MapMiLocalization.class);
                startActivity(intent);
            }
        });

        BDRutas rutas = new BDRutas(this, "BDRutas", null, 1);

        SQLiteDatabase db = rutas.getWritableDatabase();


        //Fragment fragmento = new MapasFragment();

        //getSupportFragmentManager().beginTransaction().replace(R.id.contenedor,fragmento).commit();
    }

    public void Map(View view){
        Intent intent = new Intent(getApplicationContext(),MapsActivityMapa.class);
        startActivity(intent);
    }

    public void MiLocalization(View v){
        Intent intent = new Intent(getApplicationContext(), MapMiLocalization.class);
        startActivity(intent);
    }

   // @Override
   // public void onFragmentInteraction(Uri uri) {

    //}
}
