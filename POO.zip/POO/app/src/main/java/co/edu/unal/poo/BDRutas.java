package co.edu.unal.poo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class BDRutas extends SQLiteOpenHelper {

    String sqlCreate = "CREATE TABLE Rutas (partida LatLnG, llegada LatLng)";
    String sqlCreate2 = "CREATE TABLE Rutas (partida LaTLnG, llegada LatLng, localizacion LatLng)";

    public BDRutas( Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(sqlCreate);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS Rutas");

        db.execSQL(sqlCreate2);

    }
}
